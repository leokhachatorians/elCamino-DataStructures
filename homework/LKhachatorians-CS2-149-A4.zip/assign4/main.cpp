#include "functions.h"

int main() {
    run();
    return 0;
}